<?php
$servidor = "localhost:3306";
$usuario = "root";
$senha = "";
$basedados = "maze";
?>