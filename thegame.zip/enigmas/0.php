<?php 
$resposta = $_GET['resp'];
if($resposta == "papagaio"){
	echo "true";
}else{
	echo "false";
}
?>