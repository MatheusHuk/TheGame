<?php
$servidor = "localhost";
$usuario = "id8497913_matheus";
$senha = "matheus2014";
$basedados = "id8497913_maze";
?>