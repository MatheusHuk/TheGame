<?php 
echo $_GET['vid'];
?>