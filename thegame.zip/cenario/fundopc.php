<?php 
echo '<div id="pc1"><img src="cenario/register.png" onmouseover="texto(3)" onmouseout="texto(30)" onclick="registrar()"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"><img src="cenario/sair.png" onmouseover="texto(2)" onmouseout="texto(20)" onclick="lab(0,nulo,nulo)"></div>';
?>