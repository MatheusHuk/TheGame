<?php
echo '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 
	 '<div id="pcbordap"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcbordap"></div>'.
	 
	 '<div id="lateralpc">'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'. 
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'. 
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '</div>'.
	 
	 '<div id="lateralpc">'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'. 
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'. 
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '</div>'.
	 
	 '<div id="telapc">'.
	 '<div id="pc1"><img src="cenario/register.png" onmouseover="texto(3)" onmouseout="texto(30)" onclick="registrar()"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"></div>'.
	 '<div id="pc"><img src="cenario/sair.png" onmouseover="texto(2)" onmouseout="texto(20)" onclick="lab(0,nulo,nulo)"></div>'.
	 '</div>'.
	 
	 '<div id="lateralpc">'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'. 
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'. 
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '</div>'.
	
	 '<div id="lateralpc">'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'. 
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'. 
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '</div>'.
	 
	 '<div id="pcbordap"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcp"></div>'.
	 '<div id="pcbordap"></div>'.
	 
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 
	 '<div id="lateralp">'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '</div>'.
	 '<div id="lateralp">'.
	 '<div id="simp"></div>'.
	 '<div id="simp"></div>'.
	 '<div id="simp"></div>'.
	 '<div id="simp"></div>'.
	 '</div>'.
	 
	 '<div id="teclado">'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '<div id="sim"></div>'.
	 '</div>'.
	 
	 '<div id="lateralp">'.
	 '<div id="simp"></div>'.
	 '<div id="simp"></div>'.
	 '<div id="simp"></div>'.
	 '<div id="simp"></div>'.
	 '</div>'.
	 '<div id="lateralp">'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '<div id="pcbordap"></div>'.
	 '</div>';
	 
?>