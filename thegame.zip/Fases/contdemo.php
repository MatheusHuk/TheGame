<?php 
$fase = $_GET['fase'];
if($fase == 1){
	echo '0/50';
}elseif($fase == 2){
	echo '0/51';
}elseif($fase == 3){
	echo '0/50';
}
?>