<?php
$fase = $_GET['fase'];
if($fase == 1){
	echo '<div id="ini"></div>'.
'<div id="b1" onmouseover="con(this.id)"></div>'.
'<div id="c1" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f1" onmouseover="con(this.id)"></div>'.
'<div id="g1" onmouseover="con(this.id)"></div>'.
'<div id="h1" onmouseover="con(this.id)"></div>'.
'<div id="i1" onmouseover="con(this.id)"></div>'.
'<div id="j1" onmouseover="con(this.id)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="c2" onmouseover="con(this.id)"></div>'.
'<div id="d2" onmouseover="con(this.id)"></div>'.
'<div id="e2" onmouseover="con(this.id)"></div>'.
'<div id="f2" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j2" onmouseover="con(this.id)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j3" onmouseover="con(this.id)"></div>'.

'<div id="a4" onmouseover="con(this.id)"></div>'.
'<div id="b4" onmouseover="con(this.id)"></div>'.
'<div id="c4" onmouseover="con(this.id)"></div>'.
'<div id="d4" onmouseover="con(this.id)"></div>'.
'<div id="e4" onmouseover="con(this.id)"></div>'.
'<div id="f4" onmouseover="con(this.id)"></div>'.
'<div id="g4" onmouseover="con(this.id)"></div>'.
'<div id="h4" onmouseover="con(this.id)"></div>'.
'<div id="i4" onmouseover="con(this.id)"></div>'.
'<div id="j4" onmouseover="con(this.id)"></div>'.

'<div id="a5" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="a6" onmouseover="con(this.id)"></div>'.
'<div id="b6" onmouseover="con(this.id)"></div>'.
'<div id="c6" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="e6" onmouseover="con(this.id)"></div>'.
'<div id="f6" onmouseover="con(this.id)"></div>'.
'<div id="g6" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="c7" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="e7" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="g7" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="a8" onmouseover="con(this.id)"></div>'.
'<div id="b8" onmouseover="con(this.id)"></div>'.
'<div id="c8" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="e8" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="g8" onmouseover="con(this.id)"></div>'.
'<div id="h8" onmouseover="con(this.id)"></div>'.
'<div id="i8" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="a9" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="e9" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="i9" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="a10" onmouseover="con(this.id)"></div>'.
'<div id="b10" onmouseover="con(this.id)"></div>'.
'<div id="c10" onmouseover="con(this.id)"></div>'.
'<div id="d10" onmouseover="con(this.id)"></div>'.
'<div id="e10" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="i10" onmouseover="con(this.id)"></div>'.
'<div id="win" onmouseover="win()"></div>';
}elseif($fase == 2){
	echo '<div id="ini"></div>'.
'<div id="b1" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="d1" onmouseover="con(this.id)"></div>'.
'<div id="e1" onmouseover="con(this.id)"></div>'.
'<div id="f1" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="h1" onmouseover="con(this.id)"></div>'.
'<div id="i1" onmouseover="con(this.id)"></div>'.
'<div id="j1" onmouseover="con(this.id)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="b2" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="d2" onmouseover="con(this.id)" ></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f2" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="h2" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j2" onmouseover="con(this.id)"></div>'.

'<div id="a3" onmouseover="con(this.id)"></div>'.
'<div id="b3" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="d3" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f3" onmouseover="con(this.id)"></div>'.
'<div id="g3" onmouseover="con(this.id)"></div>'.
'<div id="h3" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j3" onmouseover="con(this.id)"></div>'.

'<div id="a4" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="d4" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j4" onmouseover="con(this.id)"></div>'.

'<div id="a5" onmouseover="con(this.id)"></div>'.
'<div id="b5" onmouseover="con(this.id)"></div>'.
'<div id="c5" onmouseover="con(this.id)"></div>'.
'<div id="d5" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f5" onmouseover="con(this.id)"></div>'.
'<div id="g5" onmouseover="con(this.id)"></div>'.
'<div id="h5" onmouseover="con(this.id)"></div>'.
'<div id="i5" onmouseover="con(this.id)"></div>'.
'<div id="j5" onmouseover="con(this.id)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f6" onmouseover="con(this.id)" ></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="a7" onmouseover="con(this.id)"></div>'.
'<div id="b7" onmouseover="con(this.id)"></div>'.
'<div id="c7" onmouseover="con(this.id)"></div>'.
'<div id="d7" onmouseover="con(this.id)"><img src="item/chavea.png" onmouseover="key(this.id)" id="chaveA"><br/></div>'.
'<div id="e7" onmouseover="con(this.id)"></div>'.
'<div id="f7" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="a8" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="a9" onmouseover="con(this.id)"></div>'.
'<div id="b9" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f9" onmouseover="con(this.id)"></div>'.
'<div id="g9" onmouseover="con(this.id)"></div>'.
'<div id="portaa" onmouseover="porta(this.id)"><img src="cenario/cadeado.png"></div>'.
'<div id="naoi9" onmouseover="vida(0)"></div>'.
'<div id="naoj9" onmouseover="vida(0)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="b10" onmouseover="con(this.id)"></div>'.
'<div id="c10" onmouseover="con(this.id)"></div>'.
'<div id="d10" onmouseover="con(this.id)"></div>'.
'<div id="e10" onmouseover="con(this.id)"></div>'.
'<div id="f10" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="naoj10" onmouseover="vida(0)"></div>';
}elseif($fase == 3){
	echo '<div id="ini"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="c1" onmouseover="con(this.id)"></div>'.
'<div id="d1" onmouseover="con(this.id)"></div>'.
'<div id="e1" onmouseover="con(this.id)"></div>'.
'<div id="f1" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="h1" onmouseover="con(this.id)"></div>'.
'<div id="i1" onmouseover="con(this.id)"></div>'.
'<div id="j1" onmouseover="con(this.id)"></div>'.

'<div id="a2" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="c2" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f2" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="h2" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j2" onmouseover="con(this.id)"></div>'.

'<div id="a3" onmouseover="con(this.id)"></div>'.
'<div id="b3" onmouseover="con(this.id)"></div>'.
'<div id="c3" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f3" onmouseover="con(this.id)" ></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="h3" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j3" onmouseover="con(this.id)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="f4" onmouseover="con(this.id)"></div>'.
'<div id="g4" onmouseover="con(this.id)"><img src="item/core.png" onmouseover="ganhavida(this.id)" id="vida1F3"></div>'.
'<div id="h4" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j4" onmouseover="con(this.id)"></div>'.

'<div id="a5" onmouseover="con(this.id)"></div>'.
'<div id="b5" onmouseover="con(this.id)"></div>'.
'<div id="c5" onmouseover="con(this.id)"></div>'.
'<div id="d5" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="j5" onmouseover="con(this.id)"></div>'.

'<div id="a6" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="d6" onmouseover="con(this.id)"></div>'.
'<div id="e6" onmouseover="con(this.id)"></div>'.
'<div id="f6" onmouseover="con(this.id)"></div>'.
'<div id="g6" onmouseover="con(this.id)"></div>'.
'<div id="h6" onmouseover="con(this.id)"></div>'.
'<div id="i6" onmouseover="con(this.id)"></div>'.
'<div id="j6" onmouseover="con(this.id)"></div>'.

'<div id="a7" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="a8" onmouseover="con(this.id)"></div>'.
'<div id="b8" onmouseover="con(this.id)"></div>'.
'<div id="c8" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="c9" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="h9" onmouseover="con(this.id)"></div>'.
'<div id="i9" onmouseover="con(this.id)"></div>'.
'<div id="j9" onmouseover="con(this.id)"></div>'.

'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="c10" onmouseover="con(this.id)"></div>'.
'<div id="d10" onmouseover="con(this.id)"></div>'.
'<div id="e10" onmouseover="con(this.id)"></div>'.
'<div id="f10" onmouseover="con(this.id)"></div>'.
'<div id="g10" onmouseover="con(this.id)"></div>'.
'<div id="h10" onmouseover="con(this.id)"></div>'.
'<div id="nao" onmouseover="vida(0)"></div>'.
'<div id="win" onmouseover="win()" ></div>';
}
?>